<?php
namespace ProcessMaker\Util;

/**
 * Singleton Class Logger
 *
 * This Utility is useful to log local messages
 * @package ProcessMaker\Util
 * @author Erik Amaru Ortiz <aortiz.erik@gmail.com, erik@colosa.com>
 */
class Logger extends \Maveriks\Util\Logger
{
}

