<?php
 $ERROR_TEXT = "403 Forbidden ";
 $ERROR_DESCRIPTION = "
      You don't have permission to access the requested directory. There is either
      no index document or the directory is read-protected.<br />
      <br />
      <br />
  ";

 include ( "header.php");
?>