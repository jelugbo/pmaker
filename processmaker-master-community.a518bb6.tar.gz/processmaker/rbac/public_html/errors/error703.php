<?php
 $ERROR_TEXT = "703 style undefined   ";
 $ERROR_DESCRIPTION = "You have specified an undefined style for this workspace. <br>
      Please review your URL and try it again.<br />
      <br />
  ";
  
 include ( "header.php");
?>