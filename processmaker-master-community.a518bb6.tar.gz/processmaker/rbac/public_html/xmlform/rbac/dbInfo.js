var form_cGNXUnoxwrBYbG5uZTJxQ2I3YUts;
var i;
function loadForm_cGNXUnoxwrBYbG5uZTJxQ2I3YUts(ajaxServer)
{
if (typeof(G_Form)==='undefined') return alert('form.js was not loaded');
  form_cGNXUnoxwrBYbG5uZTJxQ2I3YUts=new G_Form(document.getElementById('cGNXUnoxwrBYbG5uZTJxQ2I3YUts'),'cGNXUnoxwrBYbG5uZTJxQ2I3YUts');
  var myForm=form_cGNXUnoxwrBYbG5uZTJxQ2I3YUts;
  myForm.ajaxServer=ajaxServer;
                                                                                                                                                                                        }
