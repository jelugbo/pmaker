<?php
 $ERROR_TEXT = "Server Error ";
 $ERROR_DESCRIPTION = "
      <br />
      An unknown error took place within our web server. <br />
      <br />
  ";

 include ( "header.php");
?>