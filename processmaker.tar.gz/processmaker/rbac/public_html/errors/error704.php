<?php
 $ERROR_TEXT = "704 DB directory not found  ";
 $ERROR_DESCRIPTION = "You have specified an invalida directory for DB files ( database definitions ). <br>
      Please review your URL and try it again.<br />
      <br />
  ";

 include ( "header.php");
?>