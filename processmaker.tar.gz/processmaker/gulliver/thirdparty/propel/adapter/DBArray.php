<?php

/*
 *  $Id: DBArray.php 536 2007-01-10 14:30:38Z heltem $
 *
 */

require_once 'propel/adapter/DBAdapter.php';

/**
 * This is used in order to connect to a virtual ARRAY database.
 *
 * @author     Fernando Ontiveros
 * @package    propel.adapter
 */
class DBArray extends DBAdapter {

	/**
	 * This method is used to ignore case.
	 *
	 * @param      in The string to transform to upper case.
	 * @return     The upper case string.
	 */
	public function toUpperCase($in)
	{
		return "UPPER(" . $in . ")";
	}

	/**
	 * This method is used to ignore case.
	 *
	 * @param      in The string whose case to ignore.
	 * @return     The string in a case that can be ignored.
	 */
	public function ignoreCase($in)
	{
		return "UPPER(" . $in . ")";
	}

	/**
	 * Returns SQL which concatenates the second string to the first.
	 *
	 * @param      string String to concatenate.
	 * @param      string String to append.
	 * @return     string
	 */
	public function concatString($s1, $s2)
	{
		return "CONCAT($s1, $s2)";
	}

	/**
	 * Returns SQL which extracts a substring.
	 *
	 * @param      string String to extract from.
	 * @param      int Offset to start from.
	 * @param      int Number of characters to extract.
	 * @return     string
	 */
	public function subString($s, $pos, $len)
	{
		return "SUBSTRING($s, $pos, $len)";
	}

	/**
	 * Returns SQL which calculates the length (in chars) of a string.
	 *
	 * @param      string String to calculate length of.
	 * @return     string
	 */
	public function strLength($s)
	{
		return "CHAR_LENGTH($s)";
	}


	/**
	 * Locks the specified table.
	 *
	 * @param      Connection $con The Creole connection to use.
	 * @param      string $table The name of the table to lock.
	 * @throws     SQLException No Statement could be created or
	 * executed.
	 */
	public function lockTable(Connection $con, $table)
	{
		$statement = $con->createStatement();
		$sql = "LOCK TABLE " . $table . " WRITE";
		$statement->executeUpdate($sql);
	}

	/**
	 * Unlocks the specified table.
	 *
	 * @param      Connection $con The Creole connection to use.
	 * @param      string $table The name of the table to unlock.
	 * @throws     SQLException No Statement could be created or
	 * executed.
	 */
	public function unlockTable(Connection $con, $table)
	{
		$statement = $con->createStatement();
		$statement->executeUpdate("UNLOCK TABLES");
	}

	/**
	 * @see        DBAdapter::quoteIdentifier()
	 */
	public function quoteIdentifier($text)
	{
		return '`' . $text . '`';
	}

}
